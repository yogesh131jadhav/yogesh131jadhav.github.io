import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from '../../service/helper.service';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit {
  title = 'basic-application';
  constructor(public helperService: HelperService,
              private router: Router) {
    if (!helperService.loggedInUser.value) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit(): void {
  }

}
