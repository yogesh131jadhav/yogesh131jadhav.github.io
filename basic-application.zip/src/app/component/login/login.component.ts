import { Component, OnInit } from '@angular/core';
import { HelperService } from '../../service/helper.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public loginFormObj: any;
  
  constructor(public helperService: HelperService,
              private router: Router,
              public http: HttpClient) {
    this.loginFormObj = {
      email: '',
      pwd: ''
    };
  }

  ngOnInit(): void {
  }
  
  handleLogin(): void {
    this.http.get('http://localhost/kishor/angular/basic-application/php/login.php').subscribe(loginAPIResponse => {
      this.helperService.loggedInUser.next(true);
      this.router.navigate(['/dashboard']);
    },(err) => console.log(err));
  }

}
