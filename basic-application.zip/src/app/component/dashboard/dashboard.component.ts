import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from '../../service/helper.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {

  constructor(public helperService: HelperService,
              private router: Router) {
    if (!helperService.loggedInUser.value) {
      this.router.navigate(['/login']);
    }
  }

}
