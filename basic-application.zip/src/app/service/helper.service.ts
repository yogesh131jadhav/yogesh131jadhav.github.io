import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HelperService {
  public loggedInUser = new BehaviorSubject(null);
  constructor() { }
}
