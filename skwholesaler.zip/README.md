# skwholesale
activePage values
1: Homepage
2. Product list page
3. Product details page
