angular.module('jobPortal')
.service('ApiService', function($timeout, $filter, $q, $rootScope, $http) {
  $rootScope.loader = false;
  this.apiBasePath = './dbAPI/handleDBAction.php';
  this.headers = {
    'Content-Type' : 'application/json'
  };
  this.fetchAll = function(tbl) {
    return $http.get('./dbAPI/login.php?txtAction=login').then((res) => this.response(res), this.notification('Error getting all users'));
  }
  this.fetchUniqueReq = function(tbl, param, id) {
    return $http.get(this.apiBasePath + '?on='+tbl+'&param='+param+'&id='+id).then((res) => this.response(res), this.notification('System error to fetch details'));
  }
  this.updateReq = function(tbl, record, id) {
    return $http.put(this.apiBasePath + '?on='+tbl+'&id='+id, JSON.stringify(record), this.headers).then((res) => this.response(res, 'Record Updated Successfuly'), this.notification('Record did not able to update due to system error'));
  }
  this.insertReq = function(tbl, record, id) {
    return $http.post(this.apiBasePath + '?on='+tbl+'&id='+id, JSON.stringify(record), this.headers).then((res) => this.response(res, 'Record Inserted Successfuly'), this.notification('Record did not able to insert due to system error'));
  }
  this.fetchReq = function(tbl) {
    return $http.get(this.apiBasePath + '?on='+tbl).then((res) => this.response(res), this.notification('System error to fetch details'));
  }
  this.response = function(res, msg = null) {
    msg && this.setNotification('success', msg);
    var deferred = $q.defer();
    deferred.resolve(res.data);
    return deferred.promise;
  }
  this.notification = function(err) {
    var deferred = $q.defer();
    deferred.resolve({error: err});
    return deferred.promise;
  }
  this.setNotification = function(notificationType, notificationMessage) {
    // notificationType: danger, warning, info, success
    $rootScope.notificationStatus = {
      notificationType: notificationType,
      notificationMessage: notificationMessage
    };
    $timeout(() => {
      this.resetNotification();
    }, 5000);
  }
  this.resetNotification = function() {
    $rootScope.notificationStatus = null;
  }
  this.parseData = function(data) {
    return JSON.parse(data);
  }
});
