angular.module('jobPortal')
.service('HelperService', function($rootScope) {
  this.parseDate = function(dateTime, format) {
    date = new Date(dateTime);
    if(format === 'dd/mm/yyyy') {
      return date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    } else if(format === 'dd/mm/yyyy : hh:mm'){
      return date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear() + " " + date.getHours() + ":" + date.getMinutes();      
    } else {
      return date;
    }
  }
  this.isJobExpire = function(freashJob) {
    return freashJob.validTill < new Date().getTime();
  }
});
