var app = angular.module("jobPortal", ["ngRoute"]);
app.config(function($routeProvider) {
  $routeProvider
  .when("/", {
    templateUrl : "./component/dashboard/dashboard.htm",
    controller : "dashboardCtrl"
  })
  .when("/login", {
    templateUrl : "./component/login/login.htm",
    controller : "loginCtrl"
  })
  .when("/logout", {
    templateUrl : "./component/logout/logout.htm",
    controller : "logoutCtrl"
  })
  .when("/register", {
    templateUrl : "./component/register/register.htm",
    controller : "registerCtrl"
  })
  .when("/forgotPassword", {
    templateUrl : "./component/forgotPassword/forgotPassword.htm",
    controller : "forgotPasswordCtrl"
  })
  .when("/setPassword", {
    templateUrl : "./component/setPassword/setPassword.htm",
    controller : "setPasswordCtrl"
  })
  .when("/job", {
    templateUrl : "./component/job/job.htm",
    controller : "jobCtrl"
  })
  .when("/listJob", {
    templateUrl : "./component/listJob/listJob.htm",
    controller : "listJobCtrl"
  })
  .when("/postJob", {
    templateUrl : "./component/postJob/postJob.htm",
    controller : "postJobCtrl"
  })
  .when("/userProfile", {
    templateUrl : "./component/userProfile/userProfile.htm",
    controller : "userProfileCtrl"
  })
  .otherwise({
    templateUrl : "./component/dashboard/dashboard.htm",
    controller : "dashboardCtrl"
  });
})
app.controller('MainCtrl', function($scope, AuthenticateService, $window, $rootScope){
  AuthenticateService.verifyAuth('#!/');
  $scope.userProfile1 = AuthenticateService.getAuthUser();
  $rootScope.notificationStatus = null;
  $scope.handleLogout = function() {
    $scope.userProfile1 = null;
    $window.location.href = '#!/logout';
  }
});
