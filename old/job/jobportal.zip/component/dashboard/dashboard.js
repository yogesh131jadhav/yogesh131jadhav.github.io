angular.module('jobPortal')
.controller('dashboardCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService) {
  AuthenticateService.verifyAuth('#!/dashboard');
});
