angular.module('jobPortal')
.controller('postJobCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService, ApiService, HelperService) {
  AuthenticateService.verifyAuth('#!/postJob');
  $scope.action = 'list';// list | new
  $scope.helperService = HelperService;
  $scope.applicantAction = null;
  $scope.selectedApplicant = null;
  $scope.jobAction = null;
  $scope.jobList = [];
  $scope.freashJob = null;
  $scope.fetchJobDetails = function() {
    ApiService.fetchReq('job').then(res => {
      $scope.jobList = res;
    });
  }
  $scope.parseDate = function(date) {
    return HelperService.parseDate(date, 'dd/mm/yyyy');
  }
  $scope.initializeJobObject = function() {
    $scope.freashJob = {
      jobID: null,
      postBy: AuthenticateService.userProfile.email,
      jobPosition: null,
      salaryRange: null,
      qualification: null,
      location: null,
      otherDetails: null,
      applicantList: [],
      postDate: null,
      validTill: null,
      jobStatus: null,
      noOfRequirement: null,
      jobDeclineReason: null,
      jobDeclinePerson: null
    };
  }
  $scope.submitNewJob = function() {
    $scope.freashJob.postDate = new Date().getTime();
    $scope.freashJob.validTill = new Date($scope.freashJob.validTill).getTime();
    $scope.freashJob.jobStatus = true;
    $scope.freashJob.jobID = 'job-' + Math.floor(Math.random() * 1000000 + 1000000);
    ApiService.insertReq('job', $scope.freashJob, $scope.freashJob.jobID).then(resp => {
      ApiService.setNotification('success', 'Job posted successfuly');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    }).catch(e => {
      ApiService.setNotification('error', 'System Error');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    });
  }
  $scope.parseItem = function(item) {
    return JSON.parse(item);
  }
  $scope.toggleView = function(customAction) {
    $scope.initializeJobObject();
    if(customAction) {
      $scope.action = customAction;
    } else {
      $scope.action = ($scope.action === 'list') ? 'new' : 'list';
    }
  }
  $scope.redirectToListPage = function() {
    $scope.fetchJobDetails();
    $scope.toggleView('list');
  }
  $scope.viewJob = function(job) {
    $scope.action = 'view';
    $scope.freashJob = job;
  }
  $scope.closeJob = function(job) {
    job.jobDeclinePerson = AuthenticateService.userProfile.email;
    job.jobStatus = false;
    ApiService.updateReq('job', $scope.freashJob, $scope.freashJob.jobID).then(resp => {
      ApiService.setNotification('success', 'Record Fetch successfuly');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    }).catch(e => {
      ApiService.setNotification('error', 'Record Fetch failed due to system error');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    });
  }
  $scope.setStatus = function(jobStatus) {
    $scope.jobAction = jobStatus;
  }
  $scope.viewApplicantDetails = function(applicant) {
    ApiService.fetchUniqueReq('login', 'email', applicant).then(resp => {
      $scope.applicantAction = 'applicantDetails';
      $scope.selectedApplicant = ApiService.parseData(resp[0].data);
    }).catch(e => {
      $scope.selectedApplicant = null;
      $scope.applicantAction = null;
      ApiService.setNotification('error', 'Did not able to fetch applicant deails');
      $scope.redirectToListPage();
    });
  }
  $scope.hideApplicantDetails = function() {
    $scope.applicantAction = null;
  }
  $scope.applicantStatus = function(job, applicant, action) {
    job['confirm'] = job['confirm'] ? job['confirm'] : [];
    job['reject'] = job['reject'] ? job['reject'] : [];
    if(job[action].indexOf(applicant) === -1) {
      job[action].push(applicant);
    }
    if(job.applicantList.indexOf(applicant) !== -1) {
      job.applicantList.splice(job.applicantList.indexOf(applicant), 1);
    }
    if(action === 'confirm') {
      if(job['reject'].indexOf(applicant) !== -1) {
        job['reject'].splice(job.applicantList.indexOf(applicant), 1);
      }
    } else {
      if(job['confirm'].indexOf(applicant) !== -1) {
        job['confirm'].splice(job.applicantList.indexOf(applicant), 1);
      }
    }
    ApiService.updateReq('job', $scope.freashJob, $scope.freashJob.jobID).then(resp => {
      ApiService.setNotification('success', 'Details Updated successfuly');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    }).catch(e => {
      ApiService.setNotification('error', 'Details Updated failed due to system error');
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    });
  }
  $scope.initializeJobObject();
  $scope.fetchJobDetails();
});
