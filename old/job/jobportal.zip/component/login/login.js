angular.module('jobPortal')
.controller('loginCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService, ApiService) {
  AuthenticateService.logout();
  $scope.submitLogin = function() {
    AuthenticateService.login($scope.userEmail, $scope.userPassword).then(function (resp) {
      if (resp.length === 0) {
        ApiService.setNotification('danger', 'Invalid Login ID and Password');
      } else {
        ApiService.setNotification('success', 'Welcome to Job Portal');
        AuthenticateService.setAuthUser(JSON.parse(resp[0].data));
        AuthenticateService.verifyAuth('#!/dashboard');
      }
    });
  }
});
