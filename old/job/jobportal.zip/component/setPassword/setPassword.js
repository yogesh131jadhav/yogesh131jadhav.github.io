angular.module('jobPortal')
.controller('setPassword', function($scope, $http, $timeout, $window, $rootScope) {
  $scope.action = 'Login';
});
