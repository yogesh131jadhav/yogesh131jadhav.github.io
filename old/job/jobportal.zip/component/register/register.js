angular.module('jobPortal')
.controller('registerCtrl', function($scope, AuthenticateService) {
  $scope.reg = null;
  $scope.submitRegister = function() {
    AuthenticateService.register($scope.reg).then(function (resp) {
      console.log('User Registered');
      AuthenticateService.verifyAuth('#!/dashboard');
    });
  }
});
