angular.module('jobPortal')
.controller('userProfileCtrl', function($scope, AuthenticateService, $rootScope, ApiService) {
  AuthenticateService.verifyAuth('#!/userProfile');
  $scope.applyJobFlag = false;
  $scope.educationalCategory = ['10','12','Diploma','Degree','Master Degree','PhD'];
  $scope.userProfileObj = $rootScope.userProfile;
  if (typeof $scope.userProfileObj.jobProfile != "undefined") {
    $scope.applyJobFlag = true;
  }
  $scope.handleApplyJob = function(status) {
    if(status) {
      $scope.initiateApplyJobObj();
    } else {
      $scope.clearApplyJobObj();
    }
  }
  $scope.initiateApplyJobObj = function() {
    if(!$scope.userProfileObj.jobProfile) {
      $scope.userProfileObj.jobProfile = {
        educational: [{
          class: '10',
          board: null,
          percentage: null
        }],
        compProfile: [{
          comp: null,
          exp: null,
          from: null,
          to: null,
          technology: null,
          role: null
        }],
        projects: [{
          project: null,
          comp: null,
          from: null,
          to: null,
          role: null,
          technology: null,
          keypoints: null
        }],
        skillsWithRating: null,
        langWithRating: null,
        preferredLocation: null,
        hobby: null
      }
    }
  }
  $scope.clearApplyJobObj = function() {
    if(!AuthenticateService.getAuthUser().jobProfile) {
      delete $scope.userProfileObj.jobProfile;
    }
  }
  $scope.addEducation = function() {
    if($scope.userProfileObj.jobProfile.educational.length < 6) {
      $scope.userProfileObj.jobProfile.educational.push({
        class: '10',
        board: null,
        percentage: null
      });
    }
  }
  $scope.deleteEducation = function(index) {
    $scope.userProfileObj.jobProfile.educational.splice(index, 1);
  }
  $scope.addCompany = function() {
    if($scope.userProfileObj.jobProfile.compProfile.length < 6) {
      $scope.userProfileObj.jobProfile.compProfile.push({
        comp: null,
        exp: null,
        from: null,
        to: null,
        technology: null,
        role: null
      });
    }
  }
  $scope.deleteCompany = function(index) {
    $scope.userProfileObj.jobProfile.compProfile.splice(index, 1);
  }
  $scope.addProject = function() {
    if($scope.userProfileObj.jobProfile.projects.length < 6) {
      $scope.userProfileObj.jobProfile.projects.push({
        project: null,
        comp: null,
        from: null,
        to: null,
        role: null,
        technology: null,
        keypoints: null
      });
    }
  }
  $scope.deleteProject = function(index) {
    $scope.userProfileObj.jobProfile.projects.splice(index, 1);
  }
  $scope.profileSubmit = function() {
    $scope.userProfileObj.DOB = new Date($scope.userProfileObj.DOB).getTime();
    ApiService.updateReq('login', $scope.userProfileObj, $scope.userProfileObj.email).then(resp => {
      $rootScope.notificationStatus = {
        notificationType: 'success',
        notificationMessage: 'Job posted successfuly'
      }
    });
  }
});
