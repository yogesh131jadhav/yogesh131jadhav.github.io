angular.module('jobPortal')
.controller('listJobCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService, ApiService, HelperService) {
  AuthenticateService.verifyAuth('#!/listJob');
  $scope.helperService = HelperService;
  $scope.action = 'list';// list | new
  $scope.jobAction = null;
  $scope.jobList = [];
  $scope.freashJob = null;
  $scope.fetchJobDetails = function() {
    ApiService.fetchReq('job').then(res => {
      $scope.jobList = res;
    });
  }
  $scope.parseDate = function(date) {
    return HelperService.parseDate(date, 'dd/mm/yyyy');
  }
  $scope.parseItem = function(item) {
    return JSON.parse(item);
  }
  $scope.viewJob = function(job) {
    $scope.action = 'view';
    $scope.freashJob = job;
  }
  $scope.setStatus = function(jobStatus) {
    $scope.jobAction = jobStatus;
  }
  $scope.applyForJob = function(job) {
    if(job.applicantList.indexOf($rootScope.userProfile.email) === -1) {
      job.applicantList.push($rootScope.userProfile.email);
      ApiService.updateReq('job', job, job.jobID).then(resp => {
        $rootScope.notificationStatus = {
          notificationType: 'success',
          notificationMessage: 'Job posted successfuly'
        }
        $scope.redirectToListPage();
      });
    }
  }
  $scope.redirectToListPage = function() {
    $scope.fetchJobDetails();
    $scope.action = 'list';
  }
  $scope.viewApplyJobBtn = function(jobData) {
    return (jobData.applicantList.length < jobData.noOfRequirement &&
            $rootScope.userProfile.email !== jobData.postBy &&
            !jobData.jobDeclinePerson &&
            (jobData.applicantList.indexOf($rootScope.userProfile.email) === -1 &&
             jobData.confirm.indexOf($rootScope.userProfile.email) === -1 &&
             jobData.reject.indexOf($rootScope.userProfile.email) === -1));
  }
  $scope.fetchJobDetails();
});
