<?php
  include('config.php');
  if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }
  else {
    if(isset($_SERVER['REQUEST_METHOD'])) {
      $tableName = $_REQUEST["on"] === 'login' ? 'dblogin' : ($_REQUEST["on"] . 'details');
      if($_SERVER['REQUEST_METHOD'] === 'GET') {
        $condition = ' ';
        if(isset($_REQUEST['param']) && isset($_REQUEST['id'])) {
          $condition = " where " . $_REQUEST['param'] . " = '" . $_REQUEST["id"] . "'";
        }
        $sql = "select * from ". $tableName . $condition;
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
          }
          print json_encode($rows);
        } else {
          print '[]';
        }
        exit;
      } else if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postdata = file_get_contents("php://input");
        $formData = json_decode($postdata);
        $condition = $_REQUEST["on"] === 'login' ? "`email` = '". $_REQUEST["id"] ."'" : "`jobId` = '". $_REQUEST["id"] ."'";
        $validationSql = "SELECT * FROM ". $tableName ." where ". $condition;
        $validationResult = mysqli_query($conn, $validationSql);
        if (mysqli_num_rows($validationResult) === 0) {
          $insertSql = "Insert into ". $tableName ." (jobId, postedEmp, jobTitle, data) VALUES ('".$_REQUEST["id"]."','". $formData -> postBy ."', '". $formData -> jobPosition ."', '". $postdata ."')";
          if (mysqli_query($conn, $insertSql)) {
            http_response_code(200);
            print 'success';
          } else {
            http_response_code(503);
            print 'Failure: Failed to insert data';
          }
        } else  {
          http_response_code(503);
          print 'Failure: Record with same product ID present';
        }
        exit;
      } else if($_SERVER['REQUEST_METHOD'] === 'PUT') {
        $postdata = file_get_contents("php://input");
        $formData = json_decode($postdata);
        $condition = $_REQUEST["on"] === 'login' ? "`email` = '". $_REQUEST["id"] ."'" : "`jobId` = '". $_REQUEST["id"] ."'";
        $setData = $_REQUEST["on"] === 'login' ? ", `srNo` = '". md5($formData->email ."". $formData->pwd) ."'" : " ";
        $validationSql = "SELECT * FROM ". $tableName ." where ". $condition;
        $validationResult = mysqli_query($conn, $validationSql);
        if (mysqli_num_rows($validationResult) !== 0) {
          $updateSql = "UPDATE ". $tableName ." SET `data`='". $postdata ."' ". $setData ." WHERE ". $condition;
          if (mysqli_query($conn, $updateSql)) {
            http_response_code(200);
            print '[]';
          } else {
            http_response_code(503);
            print 'Failure: Failed to update data';
          }
        } else {
          http_response_code(503);
          print 'Failure: Record Not Found';
        }
        exit;
      } else  {
        http_response_code(503);
        print 'Failure: Wrong action input';
      }
    }
  }
?>
