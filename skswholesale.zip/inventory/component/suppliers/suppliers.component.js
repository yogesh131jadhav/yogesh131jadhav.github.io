angular.module('inventoryManagement')
.component('suppliersComponent', {
  templateUrl: './component/suppliers/suppliers.component.html',
  bindings: {
     inventoryManagementObject: '<'
  },
  controller: function() {
  }
});
