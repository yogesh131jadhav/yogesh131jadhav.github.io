angular.module('jobPortal')
.service('AuthenticateService', function($timeout, $filter, $q, $http, $window, $rootScope, ApiService) {
  $rootScope.loader = false;
  this.apiBasePath = './dbAPI/login.php';
  this.headers = {
    'Content-Type' : 'application/json'
  };
  this.userProfile = null;
  $rootScope.userProfile = null;
  var _this = this;
  this.login = function (userName, userPassword) {
    return $http({
      method  : 'POST',
      url     : this.apiBasePath,
      data : {'userName': userName, 'pwd': userPassword, 'txtAction': 'login'},
      headers: { 'Content-Type': 'application/json' }
    }).then((res) => ApiService.response(res), ApiService.notification('Invalid Email Address or Password'));
  }
  this.register = function(regData) {
    return $http.post(this.apiBasePath, {'userName': regData.email, 'phone': regData.phone, 'pwd': regData.pwd, 'created': new Date(), 'txtAction': 'register'}, this.headers).then((res) => ApiService.response(res, 'User '+regData.email+' Registered Successfuly'), ApiService.notification('System error'));
  }
  this.verifyAuth = function(page) {
    this.userProfile = this.getAuthUser();
    $rootScope.userProfile = this.getAuthUser();
    $window.location.href = this.getAuthUser() === null ? '#!/login' : page;
  }
  this.setAuthUser = function(data) {
    $window.localStorage.setItem('loggedInUser', JSON.stringify(data));
  }
  this.getAuthUser = function() {
    return JSON.parse($window.localStorage.getItem('loggedInUser'));
  }
  this.forgotPassword = function() {
    console.log('I have triggered Forgot password In module');
  }
  this.setPassword = function() {
    console.log('I have triggered set password In module');
  }
  this.logout = function() {
    $window.localStorage.removeItem('loggedInUser');
    $rootScope.userProfile = null;
    this.verifyAuth();
  }
});
