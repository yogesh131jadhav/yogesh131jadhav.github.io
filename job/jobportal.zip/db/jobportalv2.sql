-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2020 at 12:25 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `dblogin`
--

CREATE TABLE IF NOT EXISTS `dblogin` (
  `srNo` text NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dblogin`
--

INSERT INTO `dblogin` (`srNo`, `data`) VALUES
('8ad2eb5ccc81f42ad2798a490218be86', '{"email":"test@test.com","phone":"7894561231","emailVerified":true,"phoneVerified":true,"pwd":"34fb382763a18c3674530a8b110abde3","isActive":true,"createdTime":"1585163605862","roll":["admin","staff","applicant"],"photo":"#"}'),
('fa8b855490b6471352ecee6f0718f6db', '{"email":"test1@test1.com","phone":"234234324234","emailVerified":true,"phoneVerified":true,"pwd":"5a105e8b9d40e1329780d62ea2265d8a","isActive":true,"createdTime":"2020-04-16T21:03:49.206Z","roll":["staff","applicant"],"photo":"#"}');

-- --------------------------------------------------------

--
-- Table structure for table `empdetails`
--

CREATE TABLE IF NOT EXISTS `empdetails` (
  `empId` varchar(100) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jobdetails`
--

CREATE TABLE IF NOT EXISTS `jobdetails` (
  `jobId` varchar(100) NOT NULL,
  `postedEmp` varchar(100) NOT NULL,
  `jobTitle` text NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobdetails`
--

INSERT INTO `jobdetails` (`jobId`, `postedEmp`, `jobTitle`, `data`) VALUES
('job-1248534', 'test@test.com', 'Sr Software Engg', '{"jobID":"job-1248534","postBy":"test@test.com","jobPosition":"Sr Software Engg","salaryRange":500001,"qualification":"CSE","location":"Hinjewadi","otherDetails":"test","applicantList":[],"postDate":1586989166768,"validTill":1607711400000,"jobStatus":false,"noOfRequirement":10,"jobDeclineReason":"test","jobDeclinePerson":"test@test.com"}'),
('job-1950768', 'test@test.com', 'Fresher', '{"jobID":"job-1950768","postBy":"test@test.com","jobPosition":"Fresher","salaryRange":500000,"qualification":"CSE","location":"Hinjewadi","otherDetails":"test","applicantList":[],"postDate":1586990140685,"validTill":1639247400000,"jobStatus":true,"noOfRequirement":1,"jobDeclineReason":"test","jobDeclinePerson":"test@test.com"}'),
('job-1107609', 'test@test.com', 'TL', '{"jobID":"job-1107609","postBy":"test@test.com","jobPosition":"TL","salaryRange":500001,"qualification":"CSE","location":"Pune Hinjewadi","otherDetails":"test","applicantList":[],"postDate":1586990430486,"validTill":1607711400000,"jobStatus":true,"noOfRequirement":4,"jobDeclineReason":null,"jobDeclinePerson":null}'),
('job-1120908', 'test1@test1.com', 'test', '{"jobID":"job-1120908","postBy":"test1@test1.com","jobPosition":"test","salaryRange":500001,"qualification":"test","location":"test","otherDetails":"test","applicantList":[],"postDate":1587074486606,"validTill":1607711400000,"jobStatus":true,"noOfRequirement":1,"jobDeclineReason":null,"jobDeclinePerson":null}');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
