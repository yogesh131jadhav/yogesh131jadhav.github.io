angular.module('jobPortal')
.controller('listJobCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService, ApiService, HelperService) {
  AuthenticateService.verifyAuth('#!/listJob');
  $scope.action = 'list';// list | new
  $scope.jobAction = null;
  $scope.jobList = [];
  $scope.freashJob = null;
  $scope.fetchJobDetails = function() {
    ApiService.fetchReq('job').then(res => {
      $scope.jobList = res;
    });
  }
  $scope.parseDate = function(date) {
    return HelperService.parseDate(date, 'dd/mm/yyyy');
  }
  $scope.parseItem = function(item) {
    return JSON.parse(item);
  }
  $scope.viewJob = function(job) {
    $scope.action = 'view';
    $scope.freashJob = job;
  }
  $scope.applyJob = function(job) {
    
  }
  $scope.setStatus = function(jobStatus) {
    $scope.jobAction = jobStatus;
  }
  $scope.fetchJobDetails();
});
