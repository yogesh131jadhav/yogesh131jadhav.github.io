angular.module('jobPortal')
.controller('forgotPasswordCtrl', function($scope, $http, $timeout, $window, $rootScope) {
  $scope.action = 'Login';
});
