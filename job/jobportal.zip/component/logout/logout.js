angular.module('jobPortal')
.controller('logoutCtrl', function($scope, AuthenticateService) {
  AuthenticateService.logout();
});
