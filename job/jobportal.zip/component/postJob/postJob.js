angular.module('jobPortal')
.controller('postJobCtrl', function($scope, $http, $timeout, $window, $rootScope, AuthenticateService, ApiService, HelperService) {
  AuthenticateService.verifyAuth('#!/postJob');
  $scope.action = 'list';// list | new
  $scope.jobAction = null;
  $scope.jobList = [];
  $scope.freashJob = null;
  $scope.fetchJobDetails = function() {
    ApiService.fetchReq('job').then(res => {
      $scope.jobList = res;
    });
  }
  $scope.parseDate = function(date) {
    return HelperService.parseDate(date, 'dd/mm/yyyy');
  }
  $scope.initializeJobObject = function() {
    $scope.freashJob = {
      jobID: null,
      postBy: AuthenticateService.userProfile.email,
      jobPosition: null,
      salaryRange: null,
      qualification: null,
      location: null,
      otherDetails: null,
      applicantList: [],
      postDate: null,
      validTill: null,
      jobStatus: null,
      noOfRequirement: null,
      jobDeclineReason: null,
      jobDeclinePerson: null
    };
  }
  $scope.submitNewJob = function() {
    $scope.freashJob.postDate = new Date().getTime();
    $scope.freashJob.validTill = new Date($scope.freashJob.validTill).getTime();
    $scope.freashJob.jobStatus = true;
    $scope.freashJob.jobID = 'job-' + Math.floor(Math.random() * 1000000 + 1000000);
    ApiService.insertReq('job', $scope.freashJob, $scope.freashJob.jobID).then(resp => {
      $rootScope.notificationStatus = {
        notificationType: 'success',
        notificationMessage: 'Job posted successfuly'
      }
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    }).catch(e => {
      $rootScope.notificationStatus = {
        notificationType: 'error',
        notificationMessage: 'System Error'
      }
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    });
  }
  $scope.parseItem = function(item) {
    return JSON.parse(item);
  }
  $scope.toggleView = function(customAction) {
    $scope.initializeJobObject();
    if(customAction) {
      $scope.action = customAction;
    } else {
      $scope.action = ($scope.action === 'list') ? 'new' : 'list';
    }
  }
  $scope.redirectToListPage = function() {
    $scope.fetchJobDetails();
    $scope.toggleView('list');
  }
  $scope.viewJob = function(job) {
    $scope.action = 'view';
    $scope.freashJob = job;
  }
  $scope.closeJob = function(job) {
    job.jobDeclinePerson = AuthenticateService.userProfile.email;
    job.jobStatus = false;
    ApiService.updateReq('job', $scope.freashJob, $scope.freashJob.jobID).then(resp => {
      $rootScope.notificationStatus = {
        notificationType: 'success',
        notificationMessage: 'Job posted successfuly'
      }
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    }).catch(e => {
      $rootScope.notificationStatus = {
        notificationType: 'error',
        notificationMessage: 'System Error'
      }
      $scope.initializeJobObject();
      $scope.redirectToListPage();
    });
  }
  $scope.setStatus = function(jobStatus) {
    $scope.jobAction = jobStatus;
  }
  $scope.initializeJobObject();
  $scope.fetchJobDetails();
});
