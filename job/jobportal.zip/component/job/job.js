angular.module('jobPortal')
.controller('jobCtrl', function($scope, $http, $timeout, $window, $rootScope) {
  $scope.action = 'Login';
});
