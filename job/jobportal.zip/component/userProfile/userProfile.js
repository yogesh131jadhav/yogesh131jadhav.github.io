angular.module('jobPortal')
.controller('userProfileCtrl', function($scope, AuthenticateService) {
  AuthenticateService.verifyAuth('#!/userProfile');
  $scope.applyJobFlag = false;
  $scope.educationalCategory = ['10','12','Diploma','Degree','Master Degree','PhD'];
  $scope.userProfile = AuthenticateService.getAuthUser();
  console.log($scope.userProfile);
  $scope.handleApplyJob = function() {
    if($scope.applyJobFlag) {
      $scope.initiateApplyJobObj();
    } else {
      $scope.clearApplyJobObj();
    }
  }
  $scope.initiateApplyJobObj = function() {
    if(!AuthenticateService.getAuthUser().jobProfile) {
      $scope.userProfile.jobProfile = {
        educational: [{
          class: '10',
          board: null,
          percentage: null
        }],
        compProfile: [{
          comp: null,
          exp: null,
          from: null,
          to: null,
          technology: null,
          role: null
        }],
        projects: [{
          project: null,
          comp: null,
          from: null,
          to: null,
          role: null,
          technology: null,
          keypoints: null
        }],
        DOB: null,
        address: null,
        skillsWithRating: null,
        langWithRating: null,
        preferredLocation: null,
        hobby: null
      }
    }
  }
  $scope.clearApplyJobObj = function() {
    if(!AuthenticateService.getAuthUser().jobProfile) {
      delete $scope.userProfile.jobProfile;
    }
  }
  $scope.addEducation = function() {
    if($scope.userProfile.jobProfile.educational.length < 6) {
      $scope.userProfile.jobProfile.educational.push({
        class: '10',
        board: null,
        percentage: null
      });
    }
  }
  $scope.deleteEducation = function(index) {
    $scope.userProfile.jobProfile.educational.splice(index, 1);
  }
  $scope.addCompany = function() {
    if($scope.userProfile.jobProfile.compProfile.length < 6) {
      $scope.userProfile.jobProfile.compProfile.push({
        comp: null,
        exp: null,
        from: null,
        to: null,
        technology: null,
        role: null
      });
    }
  }
  $scope.deleteCompany = function(index) {
    $scope.userProfile.jobProfile.compProfile.splice(index, 1);
  }
  $scope.addProject = function() {
    if($scope.userProfile.jobProfile.projects.length < 6) {
      $scope.userProfile.jobProfile.projects.push({
        project: null,
        comp: null,
        from: null,
        to: null,
        role: null,
        technology: null,
        keypoints: null
      });
    }
  }
  $scope.deleteProject = function(index) {
    $scope.userProfile.jobProfile.projects.splice(index, 1);
  }
  $scope.profileSubmit = function() {
    
  }
});
