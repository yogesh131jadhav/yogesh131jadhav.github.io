<?php
  include('config.php');
  if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }
  else {
    $postdata = file_get_contents("php://input");
    $formData = json_decode($postdata);
    if($formData->txtAction == "login") {
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "SELECT * FROM `dbLogin` where `srNo` = '" . md5( $formData->userName ."". $formData->pwd) . "'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
          }
          print json_encode($rows);
        } else {
          print json_encode([]);
        }
      }
      exit;
    } else if($formData->txtAction == "register") {
      $data = json_decode('{}');
      $data->email = $formData->userName;
      $data->phone = $formData->phone;
      $data->emailVerified = false;
      $data->phoneVerified = false;
      $data->pwd = md5($formData->pwd);
      $data->isActive = false;
      $data->createdTime = $formData->created;
      $data->roll = ["staff", "applicant"];
      $data->photo = "#";
      $sql = "SELECT * FROM `dbLogin` where `srNo` = '" . md5($data->email ."". $formData->pwd) . "'";
      $result = mysqli_query($conn, $sql);
      if (mysqli_num_rows($result) === 0) {
        $insertSql = "Insert into `dbLogin` (srNo, data) VALUES ('". md5($data->email ."". $formData->pwd) ."','". json_encode($data) ."')";
        if (mysqli_query($conn, $insertSql)) {
          http_response_code(200);
          print 'success';
        } else {
          http_response_code(503);
          print 'Failure: Failed to insert data';
        }
      } else {
        print 'User Already Exist';
      }
      exit;
    }
    mysqli_close($conn);
  }
?>
