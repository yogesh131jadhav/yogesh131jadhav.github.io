<?php
  include('config.php');
  if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }
  else {
    if(isset($_SERVER['REQUEST_METHOD'])) {
      if($_SERVER['REQUEST_METHOD'] === 'GET') {
        $condition = '';
        /*if(isset($_REQUEST['itemName']) && isset($_REQUEST['brandName'])) {
          $condition = " where `srNo` = '".md5($_REQUEST["itemName"].$_REQUEST["brandName"])."'";
        }*/
        $sql = "select * from ". $_REQUEST["on"] ."details ". $condition;
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                $rows[] = $row;
            }
            print json_encode($rows);
        } else {
            print '[]';
        }
        exit;
      } else if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postdata = file_get_contents("php://input");
        $formData = json_decode($postdata);
        print $validationSql = "SELECT * FROM ". $_REQUEST["on"] ."details where `jobId` = '". $_REQUEST["id"] ."'";
        $validationResult = mysqli_query($conn, $validationSql);
        if (mysqli_num_rows($validationResult) === 0) {
          $insertSql = "Insert into ". $_REQUEST["on"] ."details (jobId, postedEmp, jobTitle, data) VALUES ('".$_REQUEST["id"]."','". $formData -> postBy ."', '". $formData -> jobPosition ."', '". $postdata ."')";
          if (mysqli_query($conn, $insertSql)) {
            http_response_code(200);
            print 'success';
          } else {
            http_response_code(503);
            print 'Failure: Failed to insert data';
          }
        } else  {
          http_response_code(503);
          print 'Failure: Record with same product ID present';
        }
        exit;
      } else if($_SERVER['REQUEST_METHOD'] === 'PUT') {
        $postdata = file_get_contents("php://input");
        $formData = json_decode($postdata);
        $validationSql = "SELECT * FROM ". $_REQUEST["on"] ."details where `jobId` = '". $_REQUEST["id"] ."'";
        $validationResult = mysqli_query($conn, $validationSql);
        if (mysqli_num_rows($validationResult) !== 0) {
          $updateSql = "UPDATE ". $_REQUEST["on"] ."details SET `data`='". $postdata ."' WHERE `jobId`='". $_REQUEST["id"] ."'";
          if (mysqli_query($conn, $updateSql)) {
            http_response_code(200);
            print '[]';
          } else {
            http_response_code(503);
            print 'Failure: Failed to update data';
          }
        } else {
          http_response_code(503);
          print 'Failure: Record Not Found';
        }
        exit;
      } else  {

      }
    }
    if(isset($_REQUEST['adOn'])) {
      if(isset($_REQUEST['action'])) {
        
      } else {
        $condition = '';
        /*if(isset($_REQUEST['itemName']) && isset($_REQUEST['brandName'])) {
          $condition = " where `srNo` = '".md5($_REQUEST["itemName"].$_REQUEST["brandName"])."'";
        }*/
        $sql = "SELECT * FROM ". $_REQUEST["adOn"] ."details ". $condition;
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
          }
          print json_encode($rows);
        } else {
          print json_encode([]);
        }
        exit;
      }
      print 'Success';
    } else {
      $postdata = file_get_contents("php://input");
      $formData = json_decode($postdata);
      $param = $formData -> data;
      if(isset($param -> action)) {
        if($param -> action === 'add') {
          $sql = "Insert into ". $param -> adOn. "details (jobId, postedEmp, jobTitle, data) VALUES ('".$param -> jobID."','". $param -> postBy ."', '". $param -> jobPosition ."', '". json_encode($param) ."')";
          if (mysqli_query($conn, $sql)) {
            print 'success';
          } else {
            print 'Failure';
          }
        }
      }
    }
  }
?>
