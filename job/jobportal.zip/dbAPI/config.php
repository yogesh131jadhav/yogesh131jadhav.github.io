<?php
  if($_SERVER['SERVER_NAME'] === 'localhost') {
    $conn = mysqli_connect("localhost","root","","jobportal");
  } else {    
    $conn = mysqli_connect("localhost","justchill","mygroup2016@SK","jobportal");
  }
?>
